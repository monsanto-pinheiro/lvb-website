"""
Django settings for lvb_site project.

For more information on this file, see
https://docs.djangoproject.com/en/1.7/topics/settings/

For the full list of settings and their values, see
https://docs.djangoproject.com/en/1.7/ref/settings/
"""

# Build paths inside the project like this: os.path.join(BASE_DIR, ...)
import os

BASE_DIR = os.path.dirname(os.path.dirname(__file__))


# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/1.7/howto/deployment/checklist/

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = '83un-!c1cdw7%$0-&9#^!yec+kv)u$jr*widmampa^qb*w$of^'

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True

TEMPLATE_DEBUG = True

ALLOWED_HOSTS = ['lvb.st-andrews.ac.uk']


# Application definition

INSTALLED_APPS = (
##   'django.contrib.admin',
##    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'lvb',
)

MIDDLEWARE_CLASSES = (
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
#	http://stackoverflow.com/questions/8953783/improperlyconfigured-middleware-module-django-middleware-csrf-does-not-define
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.auth.middleware.SessionAuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
)

ROOT_URLCONF = 'lvb_site.urls'

WSGI_APPLICATION = 'lvb_site.wsgi.application'


# Database
# https://docs.djangoproject.com/en/1.7/ref/settings/#databases
# sudo python manage.py syncdb
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': '/home/projects/lvb/db/db.sqlite3',
    }
}

# Internationalization
# https://docs.djangoproject.com/en/1.7/topics/i18n/

LANGUAGE_CODE = 'en-uk'
TIME_ZONE = 'GMT'
USE_I18N = True
USE_L10N = True
USE_TZ = True

# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/1.7/howto/static-files/
# ./manage.py collectstatic
STATIC_URL = '/static/'
STATIC_ROOT = '/var/www/lvb/static/'
STATICFILES_DIRS = (
    os.path.join(BASE_DIR, "lvb/static"),
)

EMAIL_HOST="mailhost.st-andrews.ac.uk"
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_PASSWORD="C#Aejbb8 99"
EMAIL_HOST_USER="bioinformatics@st-andrews.ac.uk"

# Absolute filesystem path to the directory that will hold user-uploaded files.
# Example: "/home/media/media.lawrence.com/media/"
#MEDIA_ROOT = Constants.PATH_LVB_SGE_WORK_DIRECTORY

# URL that handles the media served from MEDIA_ROOT. Make sure to use a
# trailing slash.
# Examples: "http://media.lawrence.com/media/", "http://example.com/media/"
#MEDIA_URL = 'download'
